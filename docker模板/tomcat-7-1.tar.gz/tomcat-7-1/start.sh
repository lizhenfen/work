#!/bin/bash
sed -i 's#<Connector port="8080" protocol="HTTP/1.1"#<Connector port="'$HTTP_PORT'" protocol="HTTP/1.1"#g' conf/server.xml
/bin/sh /home/apache-tomcat/bin/catalina.sh run
